﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5
{
    public partial class Main : Form
    {
        // Instantiations
        string IntNumber, StartingNumbers, CountingNumbers;

        public Main()
        {
            InitializeComponent();
        }

        private void GenerateButton_Click_1(object sender, EventArgs e)
        {
            // Prompting SettingDialog.cs
            SettingDialog sd = new SettingDialog(); // sd = Setting Dialog
            sd.ShowDialog();


            // Executes Until Valid Numbers are Entered
            // ~ Does not execute if CANCELED is selected: Value resets to 0
            IntNumber = sd.IntNumber;
            ListVals.Items.Clear();

            // IntNumber is a string that is separated with an 'x'
            // Breaking Down IntNumber into 'start' & 'count'
            if (IntNumber != null)
            {
                string[] stringg = IntNumber.Split('x');
                StartingNumbers = stringg[0];
                CountingNumbers = stringg[1];


                // Generating the Palidromes
                int Palidromes = 0,
                    CurrentPalidromes = int.Parse(StartingNumbers);

                while(Palidromes < int.Parse(CountingNumbers))
                {
                    // Comparing Strings to its Reversed Self
                    string PaliNum1 = CurrentPalidromes.ToString();
                    string Reserved_PaliNum1 = new string(PaliNum1.Reverse().ToArray());

                    if (PaliNum1 == Reserved_PaliNum1)
                    {
                        ListVals.Items.Add(CurrentPalidromes);
                        Palidromes++;
                    }
                    CurrentPalidromes++;
                }
                //this.Invalidate();
            }
        }
    }
}
