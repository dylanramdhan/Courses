﻿namespace Lab5
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ListVals = new System.Windows.Forms.ListBox();
            this.GenerateButton = new System.Windows.Forms.Button();
            this.Title = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ListVals
            // 
            this.ListVals.FormattingEnabled = true;
            this.ListVals.ItemHeight = 20;
            this.ListVals.Location = new System.Drawing.Point(223, 209);
            this.ListVals.Name = "ListVals";
            this.ListVals.Size = new System.Drawing.Size(225, 224);
            this.ListVals.TabIndex = 8;
            // 
            // GenerateButton
            // 
            this.GenerateButton.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.GenerateButton.Location = new System.Drawing.Point(591, 293);
            this.GenerateButton.Name = "GenerateButton";
            this.GenerateButton.Size = new System.Drawing.Size(143, 39);
            this.GenerateButton.TabIndex = 7;
            this.GenerateButton.Text = "Generate";
            this.GenerateButton.UseVisualStyleBackColor = true;
            this.GenerateButton.Click += new System.EventHandler(this.GenerateButton_Click_1);
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold);
            this.Title.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Title.Location = new System.Drawing.Point(229, 99);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(514, 46);
            this.Title.TabIndex = 6;
            this.Title.Text = "Find Numeric Palindromes";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(966, 533);
            this.Controls.Add(this.ListVals);
            this.Controls.Add(this.GenerateButton);
            this.Controls.Add(this.Title);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lab #5 by Dylan Ramdhan";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox ListVals;
        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.Button GenerateButton;
    }
}

