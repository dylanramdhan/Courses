﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5
{
    public partial class SettingDialog : Form
    {
        // Instantiating
        string Numbers;

        public string IntNumber 
        {
            get
            {
                return (Numbers);
            }

            set
            {
                // nothing
            }
        }


        public SettingDialog()
        {
            InitializeComponent();
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            int start, count;

            // Validating the Input:
            //      1. Checking if the input is an Integer.
            //      2. Checking if the input is in Range.
            if (int.TryParse(StartInt.Text, out start) && int.TryParse(CountInt.Text, out count))
            {
                if ((start >= 0 && start <= 1000000000) && (count > 0 && count <= 100))
                {
                    ErrorMessage.Visible = false;

                    Numbers = start.ToString() + "x" + count.ToString();
                    DialogResult = DialogResult.OK;
                }

                else
                {
                    ErrorMessage.Visible = true;
                }
            }


            else
            {
                ErrorMessage.Visible = true;
            }
        }
    }
}
