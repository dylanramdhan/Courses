﻿namespace Lab5
{
    partial class SettingDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CANCEL_Button = new System.Windows.Forms.Button();
            this.okButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.StartInt = new System.Windows.Forms.TextBox();
            this.CountInt = new System.Windows.Forms.TextBox();
            this.ErrorMessage = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // CANCEL_Button
            // 
            this.CANCEL_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.CANCEL_Button.Location = new System.Drawing.Point(264, 220);
            this.CANCEL_Button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.CANCEL_Button.Name = "CANCEL_Button";
            this.CANCEL_Button.Size = new System.Drawing.Size(112, 35);
            this.CANCEL_Button.TabIndex = 0;
            this.CANCEL_Button.Text = "CANCEL";
            this.CANCEL_Button.UseVisualStyleBackColor = true;
            // 
            // okButton
            // 
            this.okButton.Location = new System.Drawing.Point(572, 220);
            this.okButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(112, 35);
            this.okButton.TabIndex = 1;
            this.okButton.Text = "OK";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(48, 71);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(318, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Enter a Starting Integer (0 - 1,000,000,000):";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(636, 71);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(162, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Enter Count (1 - 100):";
            // 
            // StartInt
            // 
            this.StartInt.Location = new System.Drawing.Point(374, 68);
            this.StartInt.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.StartInt.Name = "StartInt";
            this.StartInt.Size = new System.Drawing.Size(148, 26);
            this.StartInt.TabIndex = 4;
            // 
            // CountInt
            // 
            this.CountInt.Location = new System.Drawing.Point(798, 68);
            this.CountInt.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.CountInt.Name = "CountInt";
            this.CountInt.Size = new System.Drawing.Size(148, 26);
            this.CountInt.TabIndex = 5;
            // 
            // ErrorMessage
            // 
            this.ErrorMessage.AutoSize = true;
            this.ErrorMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.78182F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ErrorMessage.Location = new System.Drawing.Point(210, 142);
            this.ErrorMessage.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ErrorMessage.Name = "ErrorMessage";
            this.ErrorMessage.Size = new System.Drawing.Size(574, 29);
            this.ErrorMessage.TabIndex = 6;
            this.ErrorMessage.Text = "Please Enter a Positive Integer within the Range";
            this.ErrorMessage.Visible = false;
            // 
            // SettingDialog
            // 
            this.AcceptButton = this.okButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.CANCEL_Button;
            this.ClientSize = new System.Drawing.Size(1027, 335);
            this.ControlBox = false;
            this.Controls.Add(this.ErrorMessage);
            this.Controls.Add(this.CountInt);
            this.Controls.Add(this.StartInt);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.CANCEL_Button);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "SettingDialog";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Setting";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CANCEL_Button;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox StartInt;
        private System.Windows.Forms.TextBox CountInt;
        private System.Windows.Forms.Label ErrorMessage;
    }
}